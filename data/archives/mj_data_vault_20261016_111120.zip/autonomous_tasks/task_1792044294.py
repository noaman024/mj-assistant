import sys
import subprocess

def run_task():
    try:
        # Calculate
        result = 25 * 40
        
        # Get Python version
        version = sys.version.split()[0]
        
        print(f"Hey Noaman, calculation complete: 25 * 40 = {result}")
        print(f"Current Python version: {version}")
        print("Task done, Noaman.")
        
    except Exception as e:
        print(f"Kuch toh gadbad ho gayi, Noaman: {e}")

if __name__ == "__main__":
    run_task()
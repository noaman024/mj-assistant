import sys
import subprocess

def run_task():
    try:
        # Calculate 25 * 40
        result = 25 * 40
        
        # Get Python version
        version = sys.version.split()[0]
        
        print(f"Hey Noaman, calculation complete: 25 * 40 = {result}")
        print(f"Python version check: {version}")
        print("Done, Noaman!")
        
    except Exception as e:
        print(f"Error aa gaya, Noaman: {e}")

if __name__ == "__main__":
    run_task()